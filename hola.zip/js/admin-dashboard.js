// Admin dashboard: métricas + top 3 productos (canvas).
import { CONFIG, STORES, ORDER_STATUS } from './config.js';
import { db } from './db.js';
import { formatPrice, escapeHTML } from './ui.js';

export async function initDashboard() {
  const [orders, users] = await Promise.all([
    db.getAll(STORES.ORDERS),
    db.getAll(STORES.USERS)
  ]);

  const ingresos = orders
    .filter(o => o.status === ORDER_STATUS.SHIPPED || o.status === ORDER_STATUS.DELIVERED)
    .reduce((s, o) => s + Number(o.total || 0), 0);

  const cutoff = Date.now() - CONFIG.ACTIVE_USER_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.lastLogin && u.lastLogin >= cutoff).length;

  const totalOrders = orders.length;
  const pending = orders.filter(o => o.status === ORDER_STATUS.PENDING).length;

  document.getElementById('metrics').innerHTML = `
    <div class="metric"><div class="label">Ingresos totales</div><div class="value">${formatPrice(ingresos)}</div></div>
    <div class="metric"><div class="label">Órdenes</div><div class="value">${totalOrders}</div><div class="muted">${pending} pendientes</div></div>
    <div class="metric"><div class="label">Usuarios registrados</div><div class="value">${totalUsers}</div></div>
    <div class="metric"><div class="label">Usuarios activos (7d)</div><div class="value">${activeUsers}</div></div>
  `;

  // Top 3 productos vendidos
  const counts = new Map();
  for (const o of orders) {
    for (const it of o.items) {
      counts.set(it.productId, (counts.get(it.productId) || 0) + it.qty);
    }
  }
  const top = [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  const empty = document.getElementById('top-empty');
  const canvas = document.getElementById('top-chart');
  if (!top.length) {
    empty.hidden = false;
    canvas.style.display = 'none';
    return;
  }
  const products = await Promise.all(top.map(([id]) => db.get(STORES.PRODUCTS, id)));
  drawBarChart(canvas, top.map(([, qty], i) => ({
    label: products[i]?.title?.slice(0, 22) || `#${top[i][0]}`,
    value: qty
  })));
}

function drawBarChart(canvas, data) {
  const dpr = window.devicePixelRatio || 1;
  const cssW = canvas.clientWidth;
  const cssH = canvas.clientHeight || 280;
  canvas.width = cssW * dpr;
  canvas.height = cssH * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);

  const styles = getComputedStyle(document.documentElement);
  const text = styles.getPropertyValue('--text').trim() || '#111';
  const primary = styles.getPropertyValue('--primary').trim() || '#2563eb';
  const border = styles.getPropertyValue('--border').trim() || '#ccc';

  const pad = { top: 20, right: 20, bottom: 50, left: 40 };
  const w = cssW - pad.left - pad.right;
  const h = cssH - pad.top - pad.bottom;
  const max = Math.max(...data.map(d => d.value));
  const barW = w / data.length * 0.6;
  const gap = w / data.length * 0.4;

  ctx.strokeStyle = border;
  ctx.beginPath();
  ctx.moveTo(pad.left, pad.top + h);
  ctx.lineTo(pad.left + w, pad.top + h);
  ctx.stroke();

  ctx.fillStyle = primary;
  ctx.font = '12px system-ui';
  ctx.textAlign = 'center';
  data.forEach((d, i) => {
    const x = pad.left + i * (barW + gap) + gap / 2;
    const bh = (d.value / max) * h;
    const y = pad.top + h - bh;
    ctx.fillStyle = primary;
    ctx.fillRect(x, y, barW, bh);
    ctx.fillStyle = text;
    ctx.fillText(d.value, x + barW / 2, y - 6);
    ctx.fillText(d.label, x + barW / 2, pad.top + h + 18);
  });
}
