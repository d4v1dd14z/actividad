// Guardia de rutas por rol. Redirige antes de pintar.
// Uso: <script type="module">import { guard } from './js/guard.js'; guard('cliente');</script>
import { currentUser } from './auth.js';

export function guard(requiredRole) {
  const user = currentUser();
  if (!user) {
    const next = encodeURIComponent(location.pathname + location.search);
    location.replace(`login.html?next=${next}`);
    return null;
  }
  if (requiredRole && user.role !== requiredRole) {
    // Acceso negado: enviar a la sección correspondiente.
    location.replace(user.role === 'admin' ? 'admin.html' : 'catalogo.html');
    return null;
  }
  return user;
}
