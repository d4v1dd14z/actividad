// Registro del Service Worker (solo en producción HTTPS o http://localhost).
if ('serviceWorker' in navigator) {
  const isLocal = ['localhost', '127.0.0.1'].includes(location.hostname);
  const isHttps = location.protocol === 'https:';
  if (isLocal || isHttps) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(err => {
        console.warn('[sw] registro falló:', err);
      });
    });
  }
}
