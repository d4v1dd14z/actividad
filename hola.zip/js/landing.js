// Landing: productos destacados (top-rated) + newsletter.
import { STORES } from './config.js';
import { db } from './db.js';
import { storage } from './storage.js';
import { escapeHTML, formatPrice, renderStarsStatic, toast } from './ui.js';
import { addItem } from './cart.js';
import { CONFIG } from './config.js';

export async function initLanding() {
  await renderFeatured();
  bindNewsletter();
  bindAddToCart();
}

async function renderFeatured() {
  const grid = document.getElementById('featured-grid');
  if (!grid) return;
  grid.innerHTML = Array.from({ length: 4 }, () =>
    '<div class="product-card"><div class="thumb skeleton"></div><div class="body"><div class="skeleton" style="height:1em"></div></div></div>'
  ).join('');
  try {
    const products = await db.getAll(STORES.PRODUCTS);
    const top = products
      .slice()
      .sort((a, b) => (b.rating?.rate || 0) - (a.rating?.rate || 0))
      .slice(0, 4);
    if (!top.length) {
      grid.innerHTML = '<p class="empty">No hay productos aún.</p>';
      return;
    }
    grid.innerHTML = top.map(card).join('');
  } catch (err) {
    console.error(err);
    grid.innerHTML = '<p class="empty">No se pudo cargar los productos.</p>';
  }
}

function card(p) {
  return `
    <article class="product-card">
      <a href="producto.html?id=${p.id}" class="thumb"><img src="${escapeHTML(p.image)}" alt="${escapeHTML(p.title)}" loading="lazy"/></a>
      <div class="body">
        <div class="title">${escapeHTML(p.title)}</div>
        <div class="meta">${renderStarsStatic(p.rating?.rate || 0)} <span>(${p.rating?.count || 0})</span></div>
        <div class="price">${formatPrice(p.price)}</div>
        <div class="actions">
          <a class="btn btn-outline btn-sm" href="producto.html?id=${p.id}">Ver</a>
          <button class="btn btn-primary btn-sm" data-add="${p.id}">Agregar</button>
        </div>
      </div>
    </article>`;
}

function bindAddToCart() {
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-add]');
    if (!b) return;
    const id = Number(b.dataset.add);
    const product = await db.get(STORES.PRODUCTS, id);
    if (!product) return;
    addItem(product, 1);
    toast(`${product.title} agregado al carrito`, 'success');
  });
}

function bindNewsletter() {
  const form = document.getElementById('newsletter-form');
  const msg = document.getElementById('newsletter-msg');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    msg.textContent = '';
    msg.style.color = '';
    const email = form.email.value.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      msg.textContent = 'Ingresa un email válido.';
      return;
    }
    const list = storage.get(CONFIG.NEWSLETTER_KEY, []);
    if (list.includes(email)) {
      msg.style.color = 'var(--text-muted)';
      msg.textContent = 'Este email ya está suscrito.';
      return;
    }
    list.push(email);
    storage.set(CONFIG.NEWSLETTER_KEY, list);
    form.reset();
    toast('¡Gracias por suscribirte!', 'success');
  });
}
