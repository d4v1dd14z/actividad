// Admin: CRUD de productos.
import { STORES } from './config.js';
import { db } from './db.js';
import { escapeHTML, formatPrice, toast, confirmDialog, debounce } from './ui.js';

let ALL = [];
let query = '';

export async function initAdminProducts() {
  await load();
  document.getElementById('search').addEventListener('input', debounce(e => {
    query = e.target.value.trim().toLowerCase();
    render();
  }, 150));
  document.getElementById('new-product').addEventListener('click', () => openForm());
  document.getElementById('products-table').addEventListener('click', onTableClick);
}

async function load() {
  ALL = await db.getAll(STORES.PRODUCTS);
  render();
}

function render() {
  const tbody = document.querySelector('#products-table tbody');
  const list = ALL.filter(p =>
    !query ||
    p.title.toLowerCase().includes(query) ||
    (p.category || '').toLowerCase().includes(query)
  );
  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Sin productos</div></td></tr>';
    return;
  }
  tbody.innerHTML = list.map(p => `
    <tr>
      <td><img src="${escapeHTML(p.image)}" alt="" style="width:48px;height:48px;object-fit:contain;background:#fff;border-radius:6px;padding:2px"/></td>
      <td>${escapeHTML(p.title)}</td>
      <td><span class="badge badge-info">${escapeHTML(p.category)}</span></td>
      <td>${formatPrice(p.price)}</td>
      <td>${p.stock}</td>
      <td style="text-align:right">
        <button class="btn btn-outline btn-sm" data-edit="${p.id}">Editar</button>
        <button class="btn btn-danger btn-sm" data-delete="${p.id}">Eliminar</button>
      </td>
    </tr>`).join('');
}

async function onTableClick(e) {
  const ed = e.target.closest('[data-edit]');
  const del = e.target.closest('[data-delete]');
  if (ed) {
    const p = await db.get(STORES.PRODUCTS, Number(ed.dataset.edit));
    openForm(p);
  } else if (del) {
    const id = Number(del.dataset.delete);
    const ok = await confirmDialog({ title: 'Eliminar producto', message: '¿Seguro? Esta acción no se puede deshacer.', okText: 'Eliminar' });
    if (!ok) return;
    await db.delete(STORES.PRODUCTS, id);
    toast('Producto eliminado', 'success');
    await load();
  }
}

function openForm(p = null) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `
    <form class="modal" id="prod-form">
      <h3>${p ? 'Editar' : 'Nuevo'} producto</h3>
      <div class="field">
        <label>Título</label>
        <input name="title" required minlength="2" value="${escapeHTML(p?.title || '')}" />
      </div>
      <div class="input-row">
        <div class="field">
          <label>Precio (USD)</label>
          <input name="price" type="number" min="0" step="0.01" required value="${p?.price ?? ''}" />
        </div>
        <div class="field">
          <label>Stock</label>
          <input name="stock" type="number" min="0" step="1" required value="${p?.stock ?? 0}" />
        </div>
      </div>
      <div class="field">
        <label>Categoría</label>
        <input name="category" required value="${escapeHTML(p?.category || '')}" />
      </div>
      <div class="field">
        <label>URL de imagen</label>
        <input name="image" type="url" required value="${escapeHTML(p?.image || '')}" />
      </div>
      <div class="field">
        <label>Descripción</label>
        <textarea name="description" required minlength="5">${escapeHTML(p?.description || '')}</textarea>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" data-cancel>Cancelar</button>
        <button type="submit" class="btn btn-primary">${p ? 'Guardar' : 'Crear'}</button>
      </div>
    </form>`;
  document.body.appendChild(backdrop);
  const close = () => backdrop.remove();
  backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
  backdrop.querySelector('[data-cancel]').addEventListener('click', close);
  backdrop.querySelector('#prod-form').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = {
      title: fd.get('title').toString().trim(),
      price: Number(fd.get('price')),
      stock: Number(fd.get('stock')),
      category: fd.get('category').toString().trim(),
      image: fd.get('image').toString().trim(),
      description: fd.get('description').toString().trim(),
      rating: p?.rating || { rate: 0, count: 0 },
      createdAt: p?.createdAt || Date.now()
    };
    if (p) payload.id = p.id;
    await db.put(STORES.PRODUCTS, payload);
    toast(p ? 'Producto actualizado' : 'Producto creado', 'success');
    close();
    await load();
  });
}
