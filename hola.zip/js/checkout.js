// Carrito + checkout: render, controles, validaciones (Luhn, MM/YY, CVV), crear orden.
import { CONFIG, STORES, ORDER_STATUS } from './config.js';
import { db } from './db.js';
import { escapeHTML, formatPrice, toast, confirmDialog } from './ui.js';
import { getItems, totals, cloneItem, subItem, addItem, removeItem, clearCart, updateCartBadge } from './cart.js';
import { currentUser } from './auth.js';

export async function initCheckout() {
  render();
  document.addEventListener('cart:change', render);
  bindCartActions();
  bindCheckoutFlow();
}

function render() {
  const list = document.getElementById('cart-items');
  const items = getItems();
  if (!items.length) {
    list.innerHTML = '<div class="empty"><h3>Tu carrito está vacío</h3><a class="btn btn-primary" href="catalogo.html">Ver catálogo</a></div>';
  } else {
    list.innerHTML = items.map(it => `
      <div class="cart-item">
        <img src="${escapeHTML(it.image)}" alt="${escapeHTML(it.title)}" />
        <div>
          <div style="font-weight:600">${escapeHTML(it.title)}</div>
          <div class="muted">${formatPrice(it.price)} c/u</div>
          <div class="qty" style="margin-top:.35rem">
            <button class="btn btn-outline" data-sub="${it.productId}" aria-label="Restar">−</button>
            <span><strong>${it.qty}</strong></span>
            <button class="btn btn-outline" data-clone="${it.productId}" aria-label="Sumar">+</button>
          </div>
        </div>
        <div style="text-align:right">
          <div class="price">${formatPrice(it.price * it.qty)}</div>
          <div class="row-actions" style="margin-top:.4rem;justify-content:flex-end">
            <button class="btn btn-ghost btn-sm" data-dup="${it.productId}" title="Clonar línea">⎘</button>
            <button class="btn btn-danger btn-sm" data-remove="${it.productId}">Eliminar</button>
          </div>
        </div>
      </div>`).join('');
  }
  const { subtotal, iva, total, count } = totals();
  document.getElementById('subtotal').textContent = formatPrice(subtotal);
  document.getElementById('iva').textContent = formatPrice(iva);
  document.getElementById('total').textContent = formatPrice(total);
  document.getElementById('checkout-btn').disabled = count === 0;
  updateCartBadge();
}

function bindCartActions() {
  document.getElementById('cart-items').addEventListener('click', async e => {
    const sub = e.target.closest('[data-sub]');
    const clone = e.target.closest('[data-clone]');
    const dup = e.target.closest('[data-dup]');
    const rm = e.target.closest('[data-remove]');
    if (sub) return subItem(Number(sub.dataset.sub));
    if (clone) return cloneItem(Number(clone.dataset.clone));
    if (dup) {
      const id = Number(dup.dataset.dup);
      const product = await db.get(STORES.PRODUCTS, id);
      if (product) { addItem(product, 1); toast('Línea clonada', 'success'); }
      return;
    }
    if (rm) {
      const ok = await confirmDialog({ title: 'Quitar producto', message: '¿Eliminar este producto del carrito?', okText: 'Eliminar' });
      if (ok) removeItem(Number(rm.dataset.remove));
    }
  });
  document.getElementById('clear-btn').addEventListener('click', async () => {
    if (!getItems().length) return;
    const ok = await confirmDialog({ title: 'Vaciar carrito', message: '¿Quitar todos los productos?', okText: 'Vaciar' });
    if (ok) clearCart();
  });
}

function bindCheckoutFlow() {
  const checkoutBtn = document.getElementById('checkout-btn');
  const section = document.getElementById('checkout-section');
  checkoutBtn.addEventListener('click', () => {
    const u = currentUser();
    if (!u) {
      toast('Inicia sesión para pagar', 'warning');
      location.href = 'login.html?next=' + encodeURIComponent('carrito.html');
      return;
    }
    section.hidden = false;
    section.scrollIntoView({ behavior: 'smooth' });
  });
  setupCardFormatting();
  document.getElementById('checkout-form').addEventListener('submit', onSubmit);
}

function setupCardFormatting() {
  const num = document.getElementById('card-number');
  num.addEventListener('input', () => {
    const digits = num.value.replace(/\D/g, '').slice(0, 16);
    num.value = digits.replace(/(.{4})/g, '$1 ').trim();
  });
  const exp = document.getElementById('card-exp');
  exp.addEventListener('input', () => {
    const d = exp.value.replace(/\D/g, '').slice(0, 4);
    exp.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d;
  });
  const cvv = document.getElementById('card-cvv');
  cvv.addEventListener('input', () => { cvv.value = cvv.value.replace(/\D/g, ''); });
}

function luhn(n) {
  const d = n.replace(/\s/g, '');
  if (!/^\d{13,19}$/.test(d)) return false;
  let sum = 0, alt = false;
  for (let i = d.length - 1; i >= 0; i--) {
    let v = +d[i];
    if (alt) { v *= 2; if (v > 9) v -= 9; }
    sum += v; alt = !alt;
  }
  return sum % 10 === 0;
}

function validExpiry(s) {
  const m = /^(\d{2})\/(\d{2})$/.exec(s);
  if (!m) return false;
  const mm = +m[1], yy = +m[2];
  if (mm < 1 || mm > 12) return false;
  const now = new Date();
  const expDate = new Date(2000 + yy, mm, 0, 23, 59, 59);
  return expDate >= now;
}

function setError(id, msg) {
  const el = document.querySelector(`[data-error-for="${id}"]`);
  if (el) el.textContent = msg || '';
}

async function onSubmit(e) {
  e.preventDefault();
  const u = currentUser();
  if (!u) { toast('Inicia sesión', 'warning'); return; }
  const items = getItems();
  if (!items.length) { toast('Tu carrito está vacío', 'warning'); return; }

  const name = document.getElementById('card-name').value.trim();
  const number = document.getElementById('card-number').value;
  const exp = document.getElementById('card-exp').value;
  const cvv = document.getElementById('card-cvv').value;
  const address = document.getElementById('address').value.trim();

  let ok = true;
  setError('card-name', ''); setError('card-number', ''); setError('card-exp', ''); setError('card-cvv', ''); setError('address', '');
  if (name.length < 3) { setError('card-name', 'Nombre muy corto'); ok = false; }
  if (!luhn(number)) { setError('card-number', 'Número de tarjeta inválido'); ok = false; }
  if (!validExpiry(exp)) { setError('card-exp', 'Fecha inválida o vencida'); ok = false; }
  if (!/^\d{3,4}$/.test(cvv)) { setError('card-cvv', 'CVV inválido'); ok = false; }
  if (address.length < 5) { setError('address', 'Indica una dirección válida'); ok = false; }
  if (!ok) return;

  const { subtotal, iva, total } = totals();
  const order = {
    userEmail: u.email,
    userName: u.name,
    items: items.map(it => ({ ...it })),
    subtotal, iva, total,
    address,
    cardLast4: number.replace(/\D/g, '').slice(-4),
    createdAt: Date.now()
  };

  if (navigator.onLine) {
    await db.add(STORES.ORDERS, { ...order, status: ORDER_STATUS.PENDING });
    toast('¡Compra realizada con éxito!', 'success');
  } else {
    await db.add(STORES.PENDING_ORDERS, order);
    toast('Sin conexión: tu orden se procesará al volver en línea', 'warning', 5000);
  }
  clearCart();
  e.target.reset();
  document.getElementById('checkout-section').hidden = true;
  setTimeout(() => location.href = 'perfil.html', 1500);
}
