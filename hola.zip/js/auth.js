// Autenticación: registro, login, sesión, roles, recuperación.
// Contraseñas hasheadas con SHA-256 (Web Crypto). Sesión en sessionStorage.
import { CONFIG, STORES } from './config.js';
import { db } from './db.js';
import { session } from './storage.js';

async function sha256(text) {
  const data = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function ensureAdminSeed() {
  const existing = await db.get(STORES.USERS, CONFIG.ADMIN_SEED.email);
  if (existing) return;
  await db.put(STORES.USERS, {
    email: CONFIG.ADMIN_SEED.email,
    name: CONFIG.ADMIN_SEED.name,
    role: 'admin',
    passwordHash: await sha256(CONFIG.ADMIN_SEED.password),
    securityQuestion: 'Color favorito',
    securityAnswerHash: await sha256('azul'),
    avatar: '',
    address: '',
    createdAt: Date.now(),
    lastLogin: null
  });
}

export function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validatePassword(pw) {
  // 6+ chars, una letra y un número
  return typeof pw === 'string' && pw.length >= 6 && /[A-Za-z]/.test(pw) && /\d/.test(pw);
}

export async function register({ email, name, password, securityQuestion, securityAnswer }) {
  email = String(email || '').trim().toLowerCase();
  name = String(name || '').trim();
  if (!validateEmail(email)) throw new Error('Email inválido');
  if (name.length < 2) throw new Error('Nombre demasiado corto');
  if (!validatePassword(password)) throw new Error('Contraseña: mínimo 6 caracteres con letra y número');
  if (!securityQuestion || !securityAnswer) throw new Error('Pregunta y respuesta de seguridad requeridas');
  const exists = await db.get(STORES.USERS, email);
  if (exists) throw new Error('Ya existe una cuenta con ese email');
  const user = {
    email, name, role: 'cliente',
    passwordHash: await sha256(password),
    securityQuestion,
    securityAnswerHash: await sha256(String(securityAnswer).trim().toLowerCase()),
    avatar: '', address: '',
    createdAt: Date.now(),
    lastLogin: null
  };
  await db.put(STORES.USERS, user);
  return user;
}

export async function login(email, password) {
  email = String(email || '').trim().toLowerCase();
  const user = await db.get(STORES.USERS, email);
  if (!user) throw new Error('Credenciales inválidas');
  const hash = await sha256(password);
  if (hash !== user.passwordHash) throw new Error('Credenciales inválidas');
  user.lastLogin = Date.now();
  await db.put(STORES.USERS, user);
  const payload = { email: user.email, name: user.name, role: user.role, avatar: user.avatar };
  session.set(CONFIG.SESSION_KEY, payload);
  return payload;
}

export function logout() {
  session.remove(CONFIG.SESSION_KEY);
}

export function currentUser() {
  return session.get(CONFIG.SESSION_KEY);
}

export async function updateProfile(patch) {
  const cur = currentUser();
  if (!cur) throw new Error('No hay sesión');
  const user = await db.get(STORES.USERS, cur.email);
  if (!user) throw new Error('Usuario no encontrado');
  const merged = { ...user, ...patch };
  await db.put(STORES.USERS, merged);
  const refreshed = { email: merged.email, name: merged.name, role: merged.role, avatar: merged.avatar };
  session.set(CONFIG.SESSION_KEY, refreshed);
  return merged;
}

export async function changePasswordWithSecurity(email, securityAnswer, newPassword) {
  email = String(email || '').trim().toLowerCase();
  const user = await db.get(STORES.USERS, email);
  if (!user) throw new Error('Usuario no encontrado');
  const ansHash = await sha256(String(securityAnswer).trim().toLowerCase());
  if (ansHash !== user.securityAnswerHash) throw new Error('Respuesta incorrecta');
  if (!validatePassword(newPassword)) throw new Error('Contraseña: mínimo 6 caracteres con letra y número');
  user.passwordHash = await sha256(newPassword);
  await db.put(STORES.USERS, user);
  return true;
}

export async function getSecurityQuestion(email) {
  email = String(email || '').trim().toLowerCase();
  const user = await db.get(STORES.USERS, email);
  if (!user) throw new Error('Usuario no encontrado');
  return user.securityQuestion;
}
