// Catálogo: filtros, búsqueda en vivo (debounce), agregar al carrito.
import { STORES } from './config.js';
import { db } from './db.js';
import { debounce, escapeHTML, formatPrice, renderStarsStatic, toast } from './ui.js';
import { addItem } from './cart.js';

let ALL = [];
let state = { q: '', category: '', min: null, max: null };

export async function initCatalog() {
  try {
    ALL = await db.getAll(STORES.PRODUCTS);
  } catch (e) {
    document.getElementById('count-info').textContent = 'Error al cargar productos.';
    return;
  }
  populateCategories();
  bindFilters();
  render();
  bindAdd();
}

function populateCategories() {
  const sel = document.getElementById('category');
  const cats = Array.from(new Set(ALL.map(p => p.category).filter(Boolean))).sort();
  cats.forEach(c => {
    const o = document.createElement('option');
    o.value = c; o.textContent = c;
    sel.appendChild(o);
  });
}

function bindFilters() {
  const q = document.getElementById('q');
  const cat = document.getElementById('category');
  const mn = document.getElementById('min');
  const mx = document.getElementById('max');
  const onChange = debounce(() => {
    state.q = q.value.trim().toLowerCase();
    state.category = cat.value;
    state.min = mn.value === '' ? null : Number(mn.value);
    state.max = mx.value === '' ? null : Number(mx.value);
    render();
  }, 200);
  q.addEventListener('input', onChange);
  cat.addEventListener('change', onChange);
  mn.addEventListener('input', onChange);
  mx.addEventListener('input', onChange);
  document.getElementById('clear-filters').addEventListener('click', () => {
    q.value = ''; cat.value = ''; mn.value = ''; mx.value = '';
    state = { q: '', category: '', min: null, max: null };
    render();
  });
}

function filtered() {
  return ALL.filter(p => {
    if (state.q && !p.title.toLowerCase().includes(state.q)) return false;
    if (state.category && p.category !== state.category) return false;
    if (state.min != null && p.price < state.min) return false;
    if (state.max != null && p.price > state.max) return false;
    return true;
  });
}

function render() {
  const grid = document.getElementById('grid');
  const info = document.getElementById('count-info');
  const list = filtered();
  info.textContent = `${list.length} producto(s)`;
  if (!list.length) {
    grid.innerHTML = '<div class="empty"><h3>Sin resultados</h3><p>Prueba a cambiar los filtros.</p></div>';
    return;
  }
  grid.innerHTML = list.map(p => `
    <article class="product-card">
      <a href="producto.html?id=${p.id}" class="thumb"><img src="${escapeHTML(p.image)}" alt="${escapeHTML(p.title)}" loading="lazy"/></a>
      <div class="body">
        <div class="title">${escapeHTML(p.title)}</div>
        <div class="meta">${renderStarsStatic(p.rating?.rate || 0)} <span>(${p.rating?.count || 0})</span></div>
        <div class="price">${formatPrice(p.price)}</div>
        <div class="actions">
          <a class="btn btn-outline btn-sm" href="producto.html?id=${p.id}">Ver</a>
          <button class="btn btn-primary btn-sm" data-add="${p.id}">Agregar</button>
        </div>
      </div>
    </article>`).join('');
}

function bindAdd() {
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-add]');
    if (!b) return;
    const id = Number(b.dataset.add);
    const product = await db.get(STORES.PRODUCTS, id);
    if (!product) return;
    addItem(product, 1);
    toast(`${product.title} agregado`, 'success');
  });
}
