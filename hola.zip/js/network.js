// Indicador de conectividad y broadcast de eventos.
export function initNetworkIndicator() {
  const update = () => {
    const online = navigator.onLine;
    document.querySelectorAll('[data-net-indicator]').forEach(el => {
      el.classList.toggle('offline', !online);
      el.textContent = online ? 'En línea' : 'Sin conexión';
    });
    document.dispatchEvent(new CustomEvent('net:change', { detail: { online } }));
  };
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update();
}
