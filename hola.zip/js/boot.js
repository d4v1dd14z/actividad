// Bootstrap común: tema, red, seeds, cabecera dinámica, badge carrito.
import { initTheme } from './theme.js';
import { initNetworkIndicator } from './network.js';
import { seedProductsIfNeeded } from './api.js';
import { ensureAdminSeed, currentUser, logout } from './auth.js';
import { updateCartBadge } from './cart.js';
import { initSync } from './sync.js';

export async function boot() {
  initTheme();
  initNetworkIndicator();
  try {
    await ensureAdminSeed();
    await seedProductsIfNeeded();
  } catch (e) {
    console.error('[boot] seed error:', e);
  }
  paintHeader();
  updateCartBadge();
  initSync();
  bindMobileToggle();
  bindLogout();
}

function paintHeader() {
  const u = currentUser();
  document.querySelectorAll('[data-when-auth]').forEach(el => {
    el.classList.toggle('hidden', !u);
  });
  document.querySelectorAll('[data-when-guest]').forEach(el => {
    el.classList.toggle('hidden', !!u);
  });
  document.querySelectorAll('[data-when-admin]').forEach(el => {
    el.classList.toggle('hidden', !u || u.role !== 'admin');
  });
  document.querySelectorAll('[data-when-cliente]').forEach(el => {
    el.classList.toggle('hidden', !u || u.role !== 'cliente');
  });
  document.querySelectorAll('[data-user-name]').forEach(el => {
    el.textContent = u ? u.name : '';
  });

  // Marcar enlace activo
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-main a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === path) a.classList.add('active');
  });
}

function bindMobileToggle() {
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-mobile-toggle]');
    if (t) {
      document.querySelector('.nav-main')?.classList.toggle('open');
    }
  });
}

function bindLogout() {
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-logout]');
    if (!b) return;
    e.preventDefault();
    logout();
    location.href = 'index.html';
  });
}
