// Helpers de UI: toast, modal, escape HTML, debounce, render estrellas.
export function escapeHTML(str) {
  return String(str ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

export function debounce(fn, ms = 250) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

export function formatPrice(n) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0);
}

export function formatDate(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleString('es-VE', { dateStyle: 'medium', timeStyle: 'short' });
}

function ensureToastContainer() {
  let c = document.getElementById('toast-container');
  if (!c) {
    c = document.createElement('div');
    c.id = 'toast-container';
    document.body.appendChild(c);
  }
  return c;
}

export function toast(message, type = 'info', ms = 3000) {
  const c = ensureToastContainer();
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  c.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .3s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 320);
  }, ms);
}

export function confirmDialog({ title = 'Confirmar', message = '¿Continuar?', okText = 'Sí', cancelText = 'Cancelar' } = {}) {
  return new Promise(resolve => {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <h3>${escapeHTML(title)}</h3>
        <p>${escapeHTML(message)}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" data-cancel>${escapeHTML(cancelText)}</button>
          <button class="btn btn-danger" data-ok>${escapeHTML(okText)}</button>
        </div>
      </div>`;
    const close = (v) => { backdrop.remove(); resolve(v); };
    backdrop.addEventListener('click', e => { if (e.target === backdrop) close(false); });
    backdrop.querySelector('[data-cancel]').addEventListener('click', () => close(false));
    backdrop.querySelector('[data-ok]').addEventListener('click', () => close(true));
    document.body.appendChild(backdrop);
    backdrop.querySelector('[data-ok]').focus();
  });
}

export function renderStarsStatic(rate = 0) {
  const r = Math.round(rate);
  let html = '<span class="stars" data-static aria-label="' + r + ' de 5 estrellas">';
  for (let i = 1; i <= 5; i++) {
    html += `<span class="${i <= r ? '' : 'off'}">★</span>`;
  }
  html += '</span>';
  return html;
}

export function renderStarsInteractive(container, initial = 0, onChange) {
  container.innerHTML = '';
  container.classList.add('stars');
  let current = initial;
  const buttons = [];
  for (let i = 1; i <= 5; i++) {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = '★';
    b.dataset.value = i;
    b.setAttribute('aria-label', `${i} estrellas`);
    b.addEventListener('click', () => {
      current = i;
      paint();
      onChange?.(i);
    });
    buttons.push(b);
    container.appendChild(b);
  }
  function paint() {
    buttons.forEach(b => {
      b.classList.toggle('active', Number(b.dataset.value) <= current);
    });
  }
  paint();
  return { get value() { return current; } };
}
