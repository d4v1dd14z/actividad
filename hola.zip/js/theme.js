// Modo Día/Noche con persistencia.
import { CONFIG } from './config.js';
import { storage } from './storage.js';

export function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  storage.set(CONFIG.THEME_KEY, theme);
  document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
    btn.setAttribute('aria-pressed', theme === 'dark');
    btn.textContent = theme === 'dark' ? '☀️' : '🌙';
    btn.title = theme === 'dark' ? 'Cambiar a claro' : 'Cambiar a oscuro';
  });
}

export function initTheme() {
  const saved = storage.get(CONFIG.THEME_KEY);
  const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  applyTheme(saved || (prefersDark ? 'dark' : 'light'));
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-theme-toggle]');
    if (!btn) return;
    const cur = document.documentElement.dataset.theme;
    applyTheme(cur === 'dark' ? 'light' : 'dark');
  });
}
