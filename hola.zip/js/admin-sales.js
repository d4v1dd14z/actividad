// Admin: historial de ventas y cambio de estado.
import { STORES, ORDER_STATUS } from './config.js';
import { db } from './db.js';
import { escapeHTML, formatPrice, formatDate, toast } from './ui.js';

const STATES = [ORDER_STATUS.PENDING, ORDER_STATUS.SHIPPED, ORDER_STATUS.DELIVERED];

export async function initAdminSales() {
  await render();
  document.getElementById('orders-table').addEventListener('change', async e => {
    const sel = e.target.closest('select[data-order]');
    if (!sel) return;
    const id = Number(sel.dataset.order);
    const order = await db.get(STORES.ORDERS, id);
    if (!order) return;
    order.status = sel.value;
    await db.put(STORES.ORDERS, order);
    toast('Estado actualizado', 'success');
  });
}

async function render() {
  const orders = (await db.getAll(STORES.ORDERS)).sort((a, b) => b.createdAt - a.createdAt);
  const tbody = document.querySelector('#orders-table tbody');
  if (!orders.length) {
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">No hay ventas registradas.</div></td></tr>';
    return;
  }
  tbody.innerHTML = orders.map(o => `
    <tr>
      <td>#${o.id}</td>
      <td>${escapeHTML(o.userName)}<br><span class="muted" style="font-size:.8rem">${escapeHTML(o.userEmail)}</span></td>
      <td>${formatDate(o.createdAt)}</td>
      <td>${o.items.reduce((s, i) => s + i.qty, 0)}</td>
      <td>${formatPrice(o.total)}</td>
      <td>
        <select data-order="${o.id}">
          ${STATES.map(s => `<option value="${s}" ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </td>
    </tr>`).join('');
}
