// Carrito por usuario en localStorage.
import { CONFIG } from './config.js';
import { storage } from './storage.js';
import { currentUser } from './auth.js';

function key() {
  const u = currentUser();
  return CONFIG.CART_KEY_PREFIX + (u ? u.email : 'guest');
}

function notify() {
  document.dispatchEvent(new CustomEvent('cart:change', { detail: { items: getItems() } }));
}

export function getItems() {
  return storage.get(key(), []);
}

function save(items) {
  storage.set(key(), items);
  notify();
}

export function addItem(product, qty = 1) {
  const items = getItems();
  const found = items.find(it => it.productId === product.id);
  if (found) {
    found.qty = Math.min(99, found.qty + qty);
  } else {
    items.push({
      productId: product.id,
      title: product.title,
      price: Number(product.price) || 0,
      image: product.image,
      qty
    });
  }
  save(items);
}

export function cloneItem(productId) {
  const items = getItems();
  const found = items.find(it => it.productId === productId);
  if (!found) return;
  found.qty = Math.min(99, found.qty + 1);
  save(items);
}

export function subItem(productId) {
  const items = getItems();
  const found = items.find(it => it.productId === productId);
  if (!found) return;
  found.qty -= 1;
  const filtered = found.qty <= 0 ? items.filter(it => it.productId !== productId) : items;
  save(filtered);
}

export function removeItem(productId) {
  save(getItems().filter(it => it.productId !== productId));
}

export function clearCart() {
  save([]);
}

export function totals() {
  const items = getItems();
  const subtotal = items.reduce((s, it) => s + it.price * it.qty, 0);
  const iva = subtotal * CONFIG.IVA;
  const total = subtotal + iva;
  const count = items.reduce((s, it) => s + it.qty, 0);
  return { subtotal, iva, total, count };
}

export function updateCartBadge() {
  const { count } = totals();
  document.querySelectorAll('[data-cart-count]').forEach(el => {
    el.textContent = count;
    el.classList.toggle('hidden', count === 0);
  });
}

// Mantener el badge sincronizado.
document.addEventListener('cart:change', updateCartBadge);
window.addEventListener('storage', updateCartBadge);
