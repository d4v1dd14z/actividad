// Fetch a la API externa con AbortController + timeout (sin reintentos infinitos).
// Tras el primer seed, ya no se vuelve a llamar (control del admin).
import { CONFIG, STORES } from './config.js';
import { db } from './db.js';
import { storage } from './storage.js';

async function fetchWithTimeout(url, ms) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

// Productos semilla (fallback) si la API no responde.
const SEED_PRODUCTS = [
  { title: 'Camiseta clásica', price: 19.99, category: "men's clothing",
    description: 'Camiseta 100% algodón, cómoda y duradera.',
    image: 'https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg',
    rating: { rate: 4.5, count: 120 }, stock: 30 },
  { title: 'Mochila urbana', price: 49.50, category: "men's clothing",
    description: 'Mochila resistente al agua con compartimento para laptop.',
    image: 'https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg',
    rating: { rate: 4.7, count: 200 }, stock: 18 },
  { title: 'Collar de plata', price: 89.00, category: 'jewelery',
    description: 'Collar elegante de plata 925 para toda ocasión.',
    image: 'https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg',
    rating: { rate: 4.2, count: 80 }, stock: 12 },
  { title: 'Disco SSD 1TB', price: 109.00, category: 'electronics',
    description: 'SSD NVMe rápido para mejorar el rendimiento de tu PC.',
    image: 'https://fakestoreapi.com/img/61U7T1koQqL._AC_SX679_.jpg',
    rating: { rate: 4.8, count: 350 }, stock: 25 },
  { title: 'Chaqueta para mujer', price: 75.00, category: "women's clothing",
    description: 'Chaqueta liviana ideal para entretiempo.',
    image: 'https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_.jpg',
    rating: { rate: 4.4, count: 60 }, stock: 20 },
  { title: 'Reloj deportivo', price: 199.00, category: 'electronics',
    description: 'Reloj inteligente con GPS y monitor cardíaco.',
    image: 'https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg',
    rating: { rate: 4.6, count: 410 }, stock: 15 }
];

function normalize(p) {
  return {
    title: p.title,
    price: Number(p.price) || 0,
    category: p.category || 'general',
    description: p.description || '',
    image: p.image || '',
    rating: p.rating || { rate: 0, count: 0 },
    stock: typeof p.stock === 'number' ? p.stock : 50,
    createdAt: Date.now()
  };
}

// Siembra inicial: solo si no hay productos y no se hizo antes.
export async function seedProductsIfNeeded() {
  if (storage.get(CONFIG.SEED_FLAG_KEY)) return;
  const count = await db.count(STORES.PRODUCTS);
  if (count > 0) {
    storage.set(CONFIG.SEED_FLAG_KEY, true);
    return;
  }
  let products = [];
  if (navigator.onLine) {
    try {
      const data = await fetchWithTimeout(CONFIG.API_URL, CONFIG.API_TIMEOUT_MS);
      if (Array.isArray(data) && data.length) products = data;
    } catch (err) {
      console.warn('[api] fallback a semilla local:', err.message);
    }
  }
  if (!products.length) products = SEED_PRODUCTS;
  for (const p of products) {
    const { id, ...rest } = p; // dejamos que IndexedDB asigne id autoincremental
    await db.add(STORES.PRODUCTS, normalize(rest));
  }
  storage.set(CONFIG.SEED_FLAG_KEY, true);
}
