// Perfil: editar datos y ver órdenes propias.
import { STORES } from './config.js';
import { db } from './db.js';
import { currentUser, updateProfile } from './auth.js';
import { guard } from './guard.js';
import { escapeHTML, formatDate, formatPrice, toast } from './ui.js';

export async function initProfile() {
  const u = guard();
  if (!u) return;
  const full = await db.get(STORES.USERS, u.email);
  const form = document.getElementById('profile-form');
  form.name.value = full.name;
  form.email.value = full.email;
  form.address.value = full.address || '';
  form.avatar.value = full.avatar || '';
  if (full.avatar) document.getElementById('avatar-preview').src = full.avatar;
  form.avatar.addEventListener('input', () => {
    const v = form.avatar.value.trim();
    if (v) document.getElementById('avatar-preview').src = v;
  });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await updateProfile({
        name: form.name.value.trim(),
        address: form.address.value.trim(),
        avatar: form.avatar.value.trim()
      });
      toast('Perfil actualizado', 'success');
      document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = form.name.value.trim());
    } catch (err) {
      toast(err.message, 'error');
    }
  });

  await renderOrders(u.email);
  document.addEventListener('orders:synced', () => renderOrders(u.email));
}

async function renderOrders(email) {
  const all = await db.getAll(STORES.ORDERS);
  const mine = all.filter(o => o.userEmail === email).sort((a, b) => b.createdAt - a.createdAt);
  const wrap = document.getElementById('my-orders');
  if (!mine.length) {
    wrap.innerHTML = '<div class="empty"><p>Aún no tienes compras.</p></div>';
    return;
  }
  wrap.innerHTML = `
    <table class="table">
      <thead><tr><th>#</th><th>Fecha</th><th>Items</th><th>Total</th><th>Estado</th></tr></thead>
      <tbody>
        ${mine.map(o => `
          <tr>
            <td>#${o.id}</td>
            <td>${formatDate(o.createdAt)}</td>
            <td>${o.items.reduce((s, i) => s + i.qty, 0)}</td>
            <td>${formatPrice(o.total)}</td>
            <td><span class="badge ${badgeClass(o.status)}">${escapeHTML(o.status)}</span></td>
          </tr>`).join('')}
      </tbody>
    </table>`;
}

function badgeClass(s) {
  return s === 'Entregado' ? 'badge-success' : s === 'Enviado' ? 'badge-info' : 'badge-warning';
}
