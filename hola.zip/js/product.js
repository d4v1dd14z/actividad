// Detalle de producto + reseñas (CRUD del usuario sobre su reseña).
import { STORES } from './config.js';
import { db } from './db.js';
import { escapeHTML, formatPrice, formatDate, renderStarsStatic, renderStarsInteractive, toast } from './ui.js';
import { addItem } from './cart.js';
import { currentUser } from './auth.js';

let starsApi = null;

export async function initProduct() {
  const id = Number(new URLSearchParams(location.search).get('id'));
  const root = document.getElementById('product-root');
  if (!id) {
    root.innerHTML = '<div class="empty"><h3>Producto no encontrado</h3><a href="catalogo.html" class="btn btn-primary">Ir al catálogo</a></div>';
    return;
  }
  const product = await db.get(STORES.PRODUCTS, id);
  if (!product) {
    root.innerHTML = '<div class="empty"><h3>Producto no encontrado</h3><a href="catalogo.html" class="btn btn-primary">Ir al catálogo</a></div>';
    return;
  }
  document.title = `${product.title} — Tienda UCAB`;
  renderProduct(product);
  document.getElementById('reviews-section').hidden = false;
  await renderReviews(id);
  bindReviewForm(id);
  bindAdd(product);
}

function renderProduct(p) {
  const root = document.getElementById('product-root');
  root.innerHTML = `
    <div class="product-detail">
      <div class="hero-img"><img src="${escapeHTML(p.image)}" alt="${escapeHTML(p.title)}"/></div>
      <div>
        <span class="badge badge-info">${escapeHTML(p.category)}</span>
        <h1 style="margin-top:.5rem">${escapeHTML(p.title)}</h1>
        <div class="row" style="gap:.5rem">${renderStarsStatic(p.rating?.rate || 0)} <span class="muted">(${p.rating?.count || 0} valoraciones)</span></div>
        <p class="price-big" style="margin:1rem 0">${formatPrice(p.price)}</p>
        <p>${escapeHTML(p.description)}</p>
        <p class="muted">Stock disponible: <strong>${p.stock}</strong></p>
        <button class="btn btn-primary btn-lg" id="add-detail" ${p.stock <= 0 ? 'disabled' : ''}>${p.stock > 0 ? 'Agregar al carrito' : 'Sin stock'}</button>
      </div>
    </div>`;
}

function bindAdd(product) {
  document.getElementById('add-detail')?.addEventListener('click', () => {
    addItem(product, 1);
    toast(`${product.title} agregado al carrito`, 'success');
  });
}

async function renderReviews(productId) {
  const list = document.getElementById('reviews-list');
  const all = await db.getByIndex(STORES.REVIEWS, 'productId', productId);
  if (!all.length) {
    list.innerHTML = '<p class="muted">Aún no hay reseñas. ¡Sé el primero!</p>';
    return;
  }
  list.innerHTML = all
    .sort((a, b) => b.createdAt - a.createdAt)
    .map(r => `
      <article class="review-item">
        <header>
          <span class="author">${escapeHTML(r.userName || r.userEmail)}</span>
          <time>${formatDate(r.createdAt)}</time>
        </header>
        ${renderStarsStatic(r.rating)}
        <p style="margin-top:.5rem">${escapeHTML(r.comment)}</p>
      </article>`).join('');
}

function bindReviewForm(productId) {
  const form = document.getElementById('review-form');
  const u = currentUser();
  if (!u) return;
  // Pre-cargar reseña existente
  db.get(STORES.REVIEWS, [productId, u.email]).then(existing => {
    starsApi = renderStarsInteractive(document.getElementById('stars-input'), existing?.rating || 0);
    if (existing) form.querySelector('#review-text').value = existing.comment;
  });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const rating = starsApi?.value || 0;
    const comment = form.querySelector('#review-text').value.trim();
    if (rating < 1) { toast('Selecciona una calificación', 'warning'); return; }
    if (comment.length < 3) { toast('Escribe un comentario', 'warning'); return; }
    await db.put(STORES.REVIEWS, {
      productId, userEmail: u.email, userName: u.name,
      rating, comment, createdAt: Date.now()
    });
    // Recalcular rating del producto
    const all = await db.getByIndex(STORES.REVIEWS, 'productId', productId);
    const avg = all.reduce((s, r) => s + r.rating, 0) / all.length;
    const product = await db.get(STORES.PRODUCTS, productId);
    product.rating = { rate: Number(avg.toFixed(2)), count: all.length };
    await db.put(STORES.PRODUCTS, product);
    toast('Reseña publicada', 'success');
    renderProduct(product);
    bindAdd(product);
    await renderReviews(productId);
  });
}
