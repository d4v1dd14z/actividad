// Wrapper de IndexedDB con API basada en promesas.
import { CONFIG, STORES } from './config.js';

let dbPromise = null;

function open() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(CONFIG.DB_NAME, CONFIG.DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORES.PRODUCTS)) {
        const s = db.createObjectStore(STORES.PRODUCTS, { keyPath: 'id', autoIncrement: true });
        s.createIndex('category', 'category', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.USERS)) {
        const s = db.createObjectStore(STORES.USERS, { keyPath: 'email' });
        s.createIndex('role', 'role', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.ORDERS)) {
        db.createObjectStore(STORES.ORDERS, { keyPath: 'id', autoIncrement: true });
      }
      if (!db.objectStoreNames.contains(STORES.REVIEWS)) {
        const s = db.createObjectStore(STORES.REVIEWS, { keyPath: ['productId', 'userEmail'] });
        s.createIndex('productId', 'productId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORES.PENDING_ORDERS)) {
        db.createObjectStore(STORES.PENDING_ORDERS, { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx(storeName, mode = 'readonly') {
  return open().then(db => db.transaction(storeName, mode).objectStore(storeName));
}

function reqToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export const db = {
  async getAll(store) {
    const s = await tx(store);
    return reqToPromise(s.getAll());
  },
  async get(store, key) {
    const s = await tx(store);
    return reqToPromise(s.get(key));
  },
  async put(store, value) {
    const s = await tx(store, 'readwrite');
    return reqToPromise(s.put(value));
  },
  async add(store, value) {
    const s = await tx(store, 'readwrite');
    return reqToPromise(s.add(value));
  },
  async delete(store, key) {
    const s = await tx(store, 'readwrite');
    return reqToPromise(s.delete(key));
  },
  async clear(store) {
    const s = await tx(store, 'readwrite');
    return reqToPromise(s.clear());
  },
  async count(store) {
    const s = await tx(store);
    return reqToPromise(s.count());
  },
  async getByIndex(store, indexName, value) {
    const s = await tx(store);
    return reqToPromise(s.index(indexName).getAll(value));
  }
};
