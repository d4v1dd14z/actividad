// Configuración global del proyecto
export const CONFIG = Object.freeze({
  APP_NAME: 'Tienda UCAB',
  API_URL: 'https://fakestoreapi.com/products',
  API_TIMEOUT_MS: 8000,
  DB_NAME: 'tienda_ucab',
  DB_VERSION: 1,
  IVA: 0.16,
  ACTIVE_USER_WINDOW_DAYS: 7,
  SESSION_KEY: 'tienda_ucab_session',
  THEME_KEY: 'tienda_ucab_theme',
  CART_KEY_PREFIX: 'tienda_ucab_cart_',
  NEWSLETTER_KEY: 'tienda_ucab_newsletter',
  SEED_FLAG_KEY: 'tienda_ucab_seed_done',
  ADMIN_SEED: {
    email: 'admin@ucab.com',
    password: 'Admin123',
    name: 'Administrador',
    role: 'admin'
  }
});

export const STORES = Object.freeze({
  PRODUCTS: 'products',
  USERS: 'users',
  ORDERS: 'orders',
  REVIEWS: 'reviews',
  PENDING_ORDERS: 'pendingOrders'
});

export const ORDER_STATUS = Object.freeze({
  PENDING: 'Pendiente',
  SHIPPED: 'Enviado',
  DELIVERED: 'Entregado'
});
