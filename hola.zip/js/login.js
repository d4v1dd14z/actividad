// Login / Registro / Recuperar contraseña (UI con tabs).
import { register, login, getSecurityQuestion, changePasswordWithSecurity } from './auth.js';
import { toast } from './ui.js';

export function initLogin() {
  // Tabs
  const tabs = document.querySelectorAll('.auth-tabs button');
  const panes = document.querySelectorAll('[data-pane]');
  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(x => x.classList.toggle('active', x === t));
    panes.forEach(p => p.hidden = p.dataset.pane !== t.dataset.tab);
  }));

  // Login
  document.getElementById('login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = document.getElementById('li-msg');
    msg.textContent = '';
    try {
      const u = await login(document.getElementById('li-email').value, document.getElementById('li-pass').value);
      const next = new URLSearchParams(location.search).get('next');
      toast(`Bienvenido, ${u.name}`, 'success');
      location.href = next || (u.role === 'admin' ? 'admin.html' : 'catalogo.html');
    } catch (err) {
      msg.textContent = err.message;
    }
  });

  // Registro
  document.getElementById('register-form').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = document.getElementById('rg-msg');
    msg.textContent = '';
    try {
      await register({
        name: document.getElementById('rg-name').value,
        email: document.getElementById('rg-email').value,
        password: document.getElementById('rg-pass').value,
        securityQuestion: document.getElementById('rg-question').value,
        securityAnswer: document.getElementById('rg-answer').value
      });
      toast('Cuenta creada. Inicia sesión.', 'success');
      tabs[0].click();
    } catch (err) {
      msg.textContent = err.message;
    }
  });

  // Recuperar
  const rcLoad = document.getElementById('rc-load');
  const rcSubmit = document.getElementById('rc-submit');
  rcLoad.addEventListener('click', async () => {
    const msg = document.getElementById('rc-msg');
    msg.textContent = '';
    try {
      const q = await getSecurityQuestion(document.getElementById('rc-email').value);
      document.getElementById('rc-question').textContent = q;
      document.getElementById('rc-step2').hidden = false;
      rcSubmit.disabled = false;
    } catch (err) {
      msg.textContent = err.message;
    }
  });
  document.getElementById('recover-form').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = document.getElementById('rc-msg');
    msg.textContent = '';
    try {
      await changePasswordWithSecurity(
        document.getElementById('rc-email').value,
        document.getElementById('rc-answer').value,
        document.getElementById('rc-newpass').value
      );
      toast('Contraseña actualizada. Inicia sesión.', 'success');
      tabs[0].click();
    } catch (err) {
      msg.textContent = err.message;
    }
  });
}
