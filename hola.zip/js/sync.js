// Procesamiento de la cola offline de órdenes.
import { STORES, ORDER_STATUS } from './config.js';
import { db } from './db.js';
import { toast } from './ui.js';

export async function processPendingOrders() {
  const pending = await db.getAll(STORES.PENDING_ORDERS);
  if (!pending.length) return 0;
  let processed = 0;
  for (const p of pending) {
    const { id, ...payload } = p;
    await db.add(STORES.ORDERS, { ...payload, status: ORDER_STATUS.PENDING, syncedAt: Date.now() });
    await db.delete(STORES.PENDING_ORDERS, id);
    processed++;
  }
  if (processed > 0) {
    toast(`Se sincronizaron ${processed} compra(s) pendientes`, 'success');
    document.dispatchEvent(new CustomEvent('orders:synced'));
  }
  return processed;
}

export function initSync() {
  if (navigator.onLine) processPendingOrders().catch(console.error);
  window.addEventListener('online', () => processPendingOrders().catch(console.error));
}
