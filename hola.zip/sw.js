// Service Worker: precache del shell + cache de imágenes con estrategia stale-while-revalidate.
const CACHE_VERSION = 'v1';
const SHELL_CACHE = `shell-${CACHE_VERSION}`;
const IMG_CACHE = `img-${CACHE_VERSION}`;

const SHELL_ASSETS = [
  './',
  './index.html',
  './catalogo.html',
  './producto.html',
  './carrito.html',
  './login.html',
  './perfil.html',
  './admin.html',
  './admin-productos.html',
  './admin-ventas.html',
  './404.html',
  './manifest.webmanifest',
  './css/base.css',
  './css/components.css',
  './css/layout.css',
  './css/pages.css',
  './js/config.js',
  './js/db.js',
  './js/storage.js',
  './js/api.js',
  './js/auth.js',
  './js/guard.js',
  './js/theme.js',
  './js/network.js',
  './js/sync.js',
  './js/ui.js',
  './js/cart.js',
  './js/catalog.js',
  './js/product.js',
  './js/checkout.js',
  './js/profile.js',
  './js/landing.js',
  './js/login.js',
  './js/admin-products.js',
  './js/admin-sales.js',
  './js/admin-dashboard.js',
  './js/boot.js',
  './js/sw-register.js',
  './assets/icons/icon-192.svg',
  './assets/icons/icon-512.svg'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(SHELL_CACHE).then(c => c.addAll(SHELL_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== SHELL_CACHE && k !== IMG_CACHE).map(k => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Imágenes externas (productos): stale-while-revalidate
  if (req.destination === 'image') {
    e.respondWith(
      caches.open(IMG_CACHE).then(async cache => {
        const cached = await cache.match(req);
        const fetchPromise = fetch(req).then(res => {
          if (res.ok) cache.put(req, res.clone());
          return res;
        }).catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Navegación HTML: network-first con fallback al cache.
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then(res => {
        const copy = res.clone();
        caches.open(SHELL_CACHE).then(c => c.put(req, copy)).catch(() => {});
        return res;
      }).catch(() => caches.match(req).then(r => r || caches.match('./index.html')))
    );
    return;
  }

  // Mismo origen: cache-first
  if (url.origin === location.origin) {
    e.respondWith(
      caches.match(req).then(r => r || fetch(req).then(res => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(SHELL_CACHE).then(c => c.put(req, copy)).catch(() => {});
        }
        return res;
      }).catch(() => caches.match('./index.html')))
    );
  }
});
