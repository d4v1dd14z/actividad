# Tienda UCAB — E-commerce Vanilla (HTML5 + CSS3 + JS moderno)

Proyecto para la actividad extra de Programación Orientada a la Web (UCAB, semestre 2-2025).
**Sin frameworks.** Solo HTML, CSS y JavaScript puros (módulos ES). Funciona offline (PWA).

## Cómo ejecutar

Como usa módulos ES y Service Worker, debe servirse por HTTP (no `file://`).

Opciones rápidas:

```bash
# Python 3
cd tienda-ucab && python3 -m http.server 8080

# Node (npx)
npx serve tienda-ucab -l 8080

# VS Code: extensión "Live Server" → click derecho en index.html
```

Abrir http://localhost:8080

## Credenciales sembradas

| Rol     | Email             | Contraseña |
|---------|-------------------|------------|
| Admin   | admin@ucab.com    | Admin123   |

Los clientes se crean desde el formulario de registro.

## Estructura

```
tienda-ucab/
├── *.html                # Páginas (landing, catálogo, producto, carrito, login, perfil, admin*)
├── css/                  # Estilos (base, components, layout, pages)
├── js/                   # Módulos ES (db, auth, cart, catalog, admin*, sync…)
├── assets/               # Imágenes e iconos
├── sw.js                 # Service Worker (cache + offline)
└── manifest.webmanifest  # PWA manifest
```

## Funcionalidades cubiertas

- Landing con hero, beneficios, productos destacados, testimonios, newsletter, indicador online/offline.
- Registro/login con hash SHA-256 (Web Crypto), sesión en `sessionStorage`, roles Cliente/Admin, recuperación con pregunta de seguridad.
- Catálogo con filtros (categoría, precio), búsqueda en vivo con debounce.
- Carrito: agregar, clonar, sumar, restar, eliminar; subtotal, IVA, total.
- Checkout con validación Luhn de tarjeta.
- Detalle de producto con reseñas (1-5 estrellas + comentario).
- Admin CRUD de productos, gestión de ventas (Pendiente / Enviado / Entregado).
- Dashboard admin: ingresos, top 3 productos (canvas), usuarios registrados/activos.
- Modo Día/Noche persistente.
- Service Worker con precache del shell + cola offline de órdenes (se sincroniza al volver online).
- IndexedDB para productos, ventas, reseñas, cola de sincronización; `localStorage` para carrito/tema/newsletter.

## API externa

Carga inicial desde `https://fakestoreapi.com/products` con `AbortController` + timeout 8s.
Si falla, usa productos semilla embebidos. Tras la primera siembra **no vuelve a consultar la API**
(control total del admin via CRUD), como pide el enunciado.

## Uso de IA generativa (declaración)

Se utilizó un asistente de IA (Claude/Lovable) como apoyo para:
- Andamiaje inicial de la estructura de archivos.
- Generación de boilerplate repetitivo (wrappers de IndexedDB, helpers de UI).
- Revisión cruzada de validaciones (Luhn, debounce, AbortController) para evitar
  problemas como fetches infinitos o memory leaks.
Toda la lógica de negocio fue revisada y ajustada manualmente.
